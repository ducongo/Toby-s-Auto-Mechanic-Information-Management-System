Author: Parfait kingwaya
Student Number: 101000644
Date: 02/25/2018
Course: 2404B
Title: Assignment 2

Operating system: Linux (this program works on Window as well but you will have to use an equivalent makefile file manegement to compile or simply compile all the files all togetherr)

Purpose:

Small program which could be used by an automotive mechanic
business to keep track of their customers and their vehicles. 
This is a c++ program which uses objects.

Copilation:

While in the propper directory in the using the terminal enter the following commands

The make command helps compile all the files and links them together in order to get an object file
>make

Then execute the following command

> ./mechanicshop

Expected output:
 **** Toby's Auto Mechanic Information Management System **** 
 
                                 MAIN MENU 
 
        1. Print Customer Database 
 
        0. Exit 
 
Enter your selection:  1 

CUSTOMERS:  
 
Customer ID 0
 
    Name:                          Maurice Mooney
    Address:                       1 Bayshore Dr.     
    Phone Number:                   (613)123-7456 
 
    1 vehicle(s):  
 
	1)     Red 2007       Ford Fiesta (100000km)

Customer ID 1
 
    Name:                          Abigail atwood
    Address:                      3245 Rideau St.     
    Phone Number:                   (613)234-9677
 
    1 vehicle(s):  
 
	1)     Green 2016       Subaru Forester (40000km)

Customer ID 2
 
    Name:                          Brook Banding
    Address:                      75 Bronson Ave.     
    Phone Number:                   (613)456-2345
 
    2 vehicle(s):  
 
	1)     White 2018           Toota Camry (5000km)
	2)     White 1972     Volkswagon Beetlr (5000km)

Customer ID 3
 
    Name:                             Ethan Esser
    Address:                     425 O'Connor St.     
    Phone Number:                   (613)432-7622
 
    3 vehicle(s):  
 
	1)     Black 2010           Toota Camry (50000km)
	2)     Green 2013        Toyata Corolla (80000km)
	3)     Gold  2015           Toyota Rav4 (20000km)

Customer ID 4
 
    Name:                              Eve Engram
    Address:                    1440 Station Blv.     
    Phone Number:                   (613)562-3214
 
    3 vehicle(s):  
 
	1)      Blue 2017           Toota Prius (2000km)
	2)    Purple 2012             GM, Envoy (60000km)
	3)     Black 2015          GM, Escalade (40000km)
	4)       Red 2015           G M, Malibu (20000km)

Customer ID 5
 
    Name:                    Victor Vanvalkenburg
    Address:                        1235 Bank St.     
    Phone Number:                   (613)478-2156
 
    1 vehicle(s):  
 
	1)     Black 2007       Tesla Model s (2000km)

Press enter to continue...
	

*********************************************************************************************************************************************************************************************

											THE END 

*****************************************************************************************************************************************************************************************8***





